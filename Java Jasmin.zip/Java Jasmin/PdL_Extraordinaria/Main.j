.class public Main
.super java/lang/Object

.method public static esPrimo(D)D
.limit stack 50
.limit locals 50
dload 0
ldc2_w 2.0
dcmpl
iflt condTrue_2
ldc 0
goto condEnd_3
condTrue_2:
ldc 1
condEnd_3:
ifeq else_0
ldc2_w 0.0
dreturn
goto endif_1
else_0:
endif_1:
ldc2_w 2.0
dstore 2
whileStart_4:
dload 2
dload 0
dcmpl
iflt condTrue_6
ldc 0
goto condEnd_7
condTrue_6:
ldc 1
condEnd_7:
ifeq whileEnd_5
dload 0
dload 2
drem
dstore 4
dload 4
ldc2_w 0.0
dcmpl
ifeq condTrue_10
ldc 0
goto condEnd_11
condTrue_10:
ldc 1
condEnd_11:
ifeq else_8
ldc2_w 0.0
dreturn
goto endif_9
else_8:
endif_9:
dload 2
ldc2_w 1.0
dadd
dstore 2
goto whileStart_4
whileEnd_5:
ldc2_w 1.0
dreturn
ldc2_w 0.0
dreturn
.end method
.method public static main([Ljava/lang/String;)V
.limit stack 50
.limit locals 50
ldc2_w 29.0
dstore 0
dload 0
invokestatic Main/esPrimo(D)D
dstore 2
dload 2
ldc2_w 1.0
dcmpl
ifeq condTrue_14
ldc 0
goto condEnd_15
condTrue_14:
ldc 1
condEnd_15:
ifeq else_12
dload 0
dstore 4
getstatic java/lang/System/out Ljava/io/PrintStream;
dload 4
invokevirtual java/io/PrintStream/println(D)V
goto endif_13
else_12:
ldc2_w 0.0
dstore 6
getstatic java/lang/System/out Ljava/io/PrintStream;
dload 6
invokevirtual java/io/PrintStream/println(D)V
endif_13:
return
.end method
