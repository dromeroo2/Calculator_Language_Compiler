package calculadora;

import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

// Import de las clases relacionadas con ANTLR
import gen.lexerCalc;
import gen.parserCalc;
import gen.parserCalc.ProgramContext;


public class Main {

	public static void main(String[] args) {
        System.out.println("Iniciando compilador...");

        // Cambiar el nombre del archivo para probar diferentes ejemplos
        try (InputStream is = Main.class.getResourceAsStream("PROGRAMA3")) {
            if (is == null) {
                System.err.println("No se encontró el archivo " + is);
                System.exit(1);
            }

            // Leer el archivo fuente como string
            String source = new String(is.readAllBytes(), StandardCharsets.UTF_8);

            // Crear input stream para ANTLR
            CharStream input = CharStreams.fromString(source);

            // Crear lexer y parser
            lexerCalc lexer = new lexerCalc(input);
            CommonTokenStream tokens = new CommonTokenStream(lexer);
            parserCalc parser = new parserCalc(tokens);

            // Obtener el árbol de análisis sintáctico
            ProgramContext tree = parser.program();

            // Mostrar el árbol en consola
            System.out.println(tree.toStringTree(parser));

            // Visitar el árbol
            MiVisitor visitor = new MiVisitor();
            visitor.visit(tree);
            
            // Guardar el código Jasmin generado en un archivo
            String jasminCode = visitor.getJasminCode();
            Files.write(Paths.get("Main.j"), jasminCode.getBytes());
            System.out.println("Código Jasmin generado en Main.j");

        } catch (IOException e) {
            System.err.println("Error leyendo el archivo: " + e.getMessage());
        }
    }
}
