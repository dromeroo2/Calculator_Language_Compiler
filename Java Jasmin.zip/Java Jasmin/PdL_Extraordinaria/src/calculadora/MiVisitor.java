package calculadora;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.antlr.v4.runtime.tree.ParseTree;

import gen.*;

public class MiVisitor extends parserCalcBaseVisitor<Void> {
		
	// Variable para saber si ha escrito el encabezado alguna funcion
	private boolean classHeaderWritten = false;

	// Campos para introducir el lenguaje Jasmin
	private StringBuilder jasmin = new StringBuilder();
	private int labelCounter = 0;

	// Metodo para pasar el codigo Jasmin a String
	public String getJasminCode() {
	    return jasmin.toString();
	}

	// Metodo para crear una etiqueta
	private String newLabel(String base) {
	    return base + "_" + (labelCounter++);
	}

	// Tabla de dispersión para crear la TDS, para almacenar las direcciones de memoria de las variables
	private Map<String, Integer> variables = new HashMap<>();
	private int nextVarIndex = 0;


	// Funcion para recorrer el nodo de asignacion
	@Override
	public Void visitSentenciaAsignacion(parserCalc.SentenciaAsignacionContext ctx) {

		// recuperar el identificador
	    String nombre = ctx.asignStatement().IDENTIFIER().getText();
	    
	    // deja el valor en la pila
	    visit(ctx.asignStatement().expression());

	    // mirar si la variable ya ha sido declarada en la tabla
	    if (!variables.containsKey(nombre)) {
	        variables.put(nombre, nextVarIndex);
	        nextVarIndex += 2; // los doubles ocupan dos posiciones
	    }

	    // guardar la variable con jasmin
	    jasmin.append("dstore ").append(variables.get(nombre)).append("\n");
	    return null;
	}

	
	// Funcion para visitar el nodo de variable
	@Override
	public Void visitVariable(parserCalc.VariableContext ctx) {
		
		// recuperar el identificador
	    String nombre = ctx.IDENTIFIER().getText();
	    
	    // CONTROL DE ERRORES: variables no definidas
	    if (!variables.containsKey(nombre)) {
	        String errorMessage = "Variable no definida: " + nombre + " en la expresión " + ctx.getText();
	        throw new RuntimeException(errorMessage);
	    }
	    
	    // si está definida, se carga
	    jasmin.append("dload ").append(variables.get(nombre)).append("\n");
	    return null;
	}


	// Funcion para visitar el nodo de un print
	@Override
	public Void visitSentenciaPrint(parserCalc.SentenciaPrintContext ctx) {
	    visit(ctx.printStatement().expression()); // deja el double en la pila

	    // se crea una variable temporar por si hay una operacion en el print
	    int temp = nextVarIndex;
	    nextVarIndex += 2;

	    // codigo jasmin para pintar por pantalla con System.ot y PrintStream
	    jasmin.append("dstore ").append(temp).append("\n"); // guarda el valor double
	    jasmin.append("getstatic java/lang/System/out Ljava/io/PrintStream;\n");
	    jasmin.append("dload ").append(temp).append("\n"); // vuelve a cargarlo
	    jasmin.append("invokevirtual java/io/PrintStream/println(D)V\n");

	    return null;
	}


	// Funcion para visitar el nodo de una llamada a funcion
	@Override
	public Void visitLlamadaFuncionExpr(parserCalc.LlamadaFuncionExprContext ctx) {
		
		// recuperar el identificador
	    String nombre = ctx.IDENTIFIER().getText();

	    // comprobar si tiene argumentos
	    if (ctx.args() != null) {
	        for (var expr : ctx.args().expression()) {
	            visit(expr); // Evaluar cada argumento
	        }
	    }

	    // comprobar que el numero de argumentos es igual a la funcion original
	    int numArgs = ctx.args() != null ? ctx.args().expression().size() : 0;
	    
	    // invocar a invokestatic
	    jasmin.append("invokestatic Main/").append(nombre).append("(");
	    for (int i = 0; i < numArgs; i++) {
	        jasmin.append("D");
	    }
	    jasmin.append(")D\n");

	    return null;
	}


	// Funcion para visitar el nodo de un return
	@Override
	public Void visitSentenciaReturn(parserCalc.SentenciaReturnContext ctx) {

		// guarda el valor en la pila
	    visit(ctx.returnStatement().expression());
	    
	    // genera codigo jasmin para el return
	    jasmin.append("dreturn\n");
	    return null;
	}


	// Funcion para visitar el nodo de un IF
    @Override
    public Void visitSentenciaIf(parserCalc.SentenciaIfContext ctx) {
    	
    	// creacion de las etiquetas para manejar el if
        String elseLabel = newLabel("else");
        String endLabel = newLabel("endif");

        // evaluar la condición, deja 0 o 1 en pila
        visit(ctx.ifStatement().condition());

        // saltar a ELSE si condición es falsa
        jasmin.append("ifeq ").append(elseLabel).append("\n");

        // THEN
        List<parserCalc.SentenceContext> thenSentences = new ArrayList<>();
        List<parserCalc.SentenceContext> elseSentences = new ArrayList<>();

        boolean inElse = false;
        for (ParseTree child : ctx.ifStatement().children) {
            if (child.getText().equals("ELSE")) {
                inElse = true;
                continue;
            }
            if (child instanceof parserCalc.SentenceContext sentence) {
                if (inElse) {
                    elseSentences.add(sentence);
                } else {
                    thenSentences.add(sentence);
                }
            }
        }

        for (var s : thenSentences) {
            visit(s);
        }

        jasmin.append("goto ").append(endLabel).append("\n");

        // ELSE
        jasmin.append(elseLabel).append(":\n");
        for (var s : elseSentences) {
            visit(s);
        }

        // ENDIF
        jasmin.append(endLabel).append(":\n");

        return null;
    }



    // Funcion para visitar un nodo de un while
    @Override
    public Void visitSentenciaWhile(parserCalc.SentenciaWhileContext ctx) {
        
    	// etiquetas para manejar el control del bucle
    	String startLabel = newLabel("whileStart");
        String endLabel = newLabel("whileEnd");

        // marcamos que empezamos el bucle con una etiqueta
        jasmin.append(startLabel).append(":\n");

        // Evaluar condición
        visit(ctx.whileStatement().condition());

        // si ya no se cumple la condicion, se salta a la etiqueta endLabel
        jasmin.append("ifeq ").append(endLabel).append("\n");

        // se ejecutan las sentencias de dentro del bucle
        for (var s : ctx.whileStatement().sentence()) {
            visit(s);
        }

        // se vuelve al inicio del bucle
        jasmin.append("goto ").append(startLabel).append("\n");
        
        // si no se ha cumplido la condicion se salta aqui y se acaba
        jasmin.append(endLabel).append(":\n");

        return null;
    }


    // Funcion para visitar un nodo de un for
    @Override
    public Void visitSentenciaFor(parserCalc.SentenciaForContext ctx) {
    	
    	// recupera el identificador
        String varName = ctx.forStatement().IDENTIFIER().getText();
        
        // mira si la variable que se usa en el for se ha usado antes
        int index;
        if (!variables.containsKey(varName)) {
        	//si se ha isado antes se mueve el indice para no chocar
            index = nextVarIndex;
            variables.put(varName, index);
            nextVarIndex += 2;
        } else {
        	//si no se ha usado se obtiene el indice
            index = variables.get(varName);
        }

        // valor inicial
        visit(ctx.forStatement().expression(0));
        jasmin.append("dstore ").append(index).append("\n");

        // limite superior
        int limitIndex = nextVarIndex;
        nextVarIndex += 2;
        visit(ctx.forStatement().expression(1));
        jasmin.append("dstore ").append(limitIndex).append("\n");
        
        // etiquetas para controlar el for
        String loopStart = newLabel("forStart");
        String loopEnd = newLabel("forEnd");

        // etiqueta que marca el inicio del for
        jasmin.append(loopStart).append(":\n");

        // comparar i <= limite
        jasmin.append("dload ").append(index).append("\n");
        jasmin.append("dload ").append(limitIndex).append("\n");
        jasmin.append("dcmpl\n");
        jasmin.append("ifgt ").append(loopEnd).append("\n");

        // cuerpo del bucle
        visit(ctx.forStatement().beginStatement());

        // i = i + 1
        jasmin.append("dload ").append(index).append("\n");
        jasmin.append("ldc2_w 1.0\n");
        jasmin.append("dadd\n");
        jasmin.append("dstore ").append(index).append("\n");

        // vuelve al inicio del bucle
        jasmin.append("goto ").append(loopStart).append("\n");
        
        // si no cumple la condicion y debe acabar, salta aqui
        jasmin.append(loopEnd).append(":\n");

        return null;
    }

    
    // Funcion para visitar el nodo de la condicion de una comparacion
    @Override
    public Void visitCondicionComparacion(parserCalc.CondicionComparacionContext ctx) {
        visit(ctx.expression(0)); // izquierda
        visit(ctx.expression(1)); // derecha
        jasmin.append("dcmpl\n"); // compara dos doubles

        // etiquetas de control
        String labelTrue = newLabel("condTrue");
        String labelEnd = newLabel("condEnd");

        // miramos que operación es
        switch (ctx.compOperator().getText()) {
            case "<":
                jasmin.append("iflt ").append(labelTrue).append("\n");
                break;
            case ">":
                jasmin.append("ifgt ").append(labelTrue).append("\n");
                break;
            case "=":
                jasmin.append("ifeq ").append(labelTrue).append("\n");
                break;
            default:
                throw new RuntimeException("Operador no soportado");
        }

        // si no se cumple, false (0)
        jasmin.append("ldc 0\n");
        jasmin.append("goto ").append(labelEnd).append("\n");

        // si se cumple, true (1)
        jasmin.append(labelTrue).append(":\n");
        jasmin.append("ldc 1\n");

        jasmin.append(labelEnd).append(":\n");
        return null;
    }






    // Funcion para visitar un nodo de una llamada a funcion
    @Override
    public Void visitSentenciaLlamadaFuncion(parserCalc.SentenciaLlamadaFuncionContext ctx) {
        visit(ctx.functionCallStatement());

        // Si se llama a una función que devuelve un valor, pero no se usa, descártalo
        jasmin.append("pop2\n"); // elimina un double de la pila (2 slots)

        return null;
    }

    
    // Funcion para visitar un nodo que define una funcion
    @Override
    public Void visitDefinicionFuncion(parserCalc.DefinicionFuncionContext ctx) {
        String nombre = ctx.IDENTIFIER().getText();

        // escribimos encabezado de clase solo una vez
        if (!classHeaderWritten) {
            jasmin.append(".class public Main\n");
            jasmin.append(".super java/lang/Object\n\n");
            classHeaderWritten = true;
        }

        // Guardar contexto anterior
        Map<String, Integer> oldVars = new HashMap<>(variables);
        int oldIndex = nextVarIndex;

        variables.clear();
        nextVarIndex = 0;

        // Parámetros
        List<String> params = new ArrayList<>();
        if (ctx.param() != null) {
            for (var id : ctx.param().IDENTIFIER()) {
                params.add(id.getText());
                variables.put(id.getText(), nextVarIndex);
                nextVarIndex += 2; // double = 2 slots
            }
        }

        // Cabecera del método
        if (nombre.equals("main")) {
            jasmin.append(".method public static main([Ljava/lang/String;)V\n");
        } else {
            jasmin.append(".method public static ").append(nombre).append("(");
            for (int i = 0; i < params.size(); i++) {
                jasmin.append("D");
            }
            jasmin.append(")D\n");
        }

        jasmin.append(".limit stack 50\n");
        jasmin.append(".limit locals 50\n");

        // visitar cada hijo del contenido de la función
        for (ParseTree child : ctx.children) {
            visit(child);  // Esto asegura que se ejecuten RETURN, PRINT
        }

        // Si es main y no hay return explícito
        if (nombre.equals("main")) {
            jasmin.append("return\n");
        } else {
            jasmin.append("ldc2_w 0.0\n"); // valor por defecto si falta return
            jasmin.append("dreturn\n");
        }

        jasmin.append(".end method\n");

        // Restaurar contexto
        variables = oldVars;
        nextVarIndex = oldIndex;

        return null;
    }




    // Funcion que visita un node de una suma o una resta
    @Override
    public Void visitSumaResta(parserCalc.SumaRestaContext ctx) {
    	
    	// se guardan los operadores
        visit(ctx.expression(0));
        visit(ctx.expression(1));

        // se ve que operacion es
        switch (ctx.op.getType()) {
            case lexerCalc.PLUS:
                jasmin.append("dadd\n");
                break;
            case lexerCalc.MINUS:
                jasmin.append("dsub\n");
                break;
        }
        return null;
    }

    // Funcion que visita un nodo de una multiplicacion, division o modulo
    @Override
    public Void visitMultDivMod(parserCalc.MultDivModContext ctx) {
    	
    	// se guardan los operadores
        visit(ctx.expression(0));
        visit(ctx.expression(1));

        // se mira que operacion es
        switch (ctx.op.getType()) {
            case lexerCalc.TIMES:
                jasmin.append("dmul\n");
                break;
            case lexerCalc.DIVIDE:
                jasmin.append("ddiv\n");
                break;
            case lexerCalc.MOD:
                jasmin.append("drem\n"); // cuidado con JVM antigua
                break;
        }
        return null;
    }


    // Funcion para visitar un nodo de una raiz cuadrada
    @Override
    public Void visitRaizCuadrada(parserCalc.RaizCuadradaContext ctx) {
        visit(ctx.expression()); // que va a dejar un double
        jasmin.append("invokestatic java/lang/Math/sqrt(D)D\n"); // se llama a la función sqrt de java para hacer la operación raíz cuadrada
        return null;
    }


    // Funcion para visitar un nodo de una potencia
    @Override
    public Void visitPotencia(parserCalc.PotenciaContext ctx) {
        visit(ctx.expression(0)); // base que pasamos a double

        visit(ctx.expression(1)); // exponente que pasamos a double

        jasmin.append("invokestatic java/lang/Math/pow(DD)D\n"); // se llama a la función pow de java para hacer la operación potencia
        return null;
    }

    
    // Funcion para visitar un nodo de bloque begin
    @Override
    public Void visitBloqueBegin(parserCalc.BloqueBeginContext ctx) {
        //System.out.println("Bloque BEGIN...END con " + ctx.sentence().size() + " sentencias.");
        return visitChildren(ctx);
    }
    
    
    // Funcion para visitar un nodo de un numero
    @Override
    public Void visitNumero(parserCalc.NumeroContext ctx) {
    	
    	// recupera el numero
        String valor = ctx.NUMBER().getText();

        // fuerza que todos los números sean doubles, validos para Jasmin
        if (!valor.contains(".")) {
            valor += ".0";
        }
        
        // carga el numero
        jasmin.append("ldc2_w ").append(valor).append("\n");
        return null;
    }



    // Funcion para visitar un nodo de negacion (signo negativo)
    @Override
    public Void visitNegacion(parserCalc.NegacionContext ctx) {
        visit(ctx.expression()); // deja - en la pila
        
        // hace el numero negativo
        jasmin.append("ineg\n");
        return null;
    }

    // Funcion para visitar un nodo de parentesis
    @Override
    public Void visitParentesis(parserCalc.ParentesisContext ctx) {
        return visit(ctx.expression());
    }

}
