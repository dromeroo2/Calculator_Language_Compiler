.class public Main
.super java/lang/Object

.method public static interesCompuesto(DDD)D
.limit stack 50
.limit locals 50
ldc2_w 0.0
dstore 6
whileStart_0:
dload 6
dload 4
dcmpl
iflt condTrue_2
ldc 0
goto condEnd_3
condTrue_2:
ldc 1
condEnd_3:
ifeq whileEnd_1
dload 0
dstore 8
getstatic java/lang/System/out Ljava/io/PrintStream;
dload 8
invokevirtual java/io/PrintStream/println(D)V
dload 0
dload 2
dmul
dstore 10
dload 0
dload 10
dadd
dstore 0
dload 6
ldc2_w 1.0
dadd
dstore 6
goto whileStart_0
whileEnd_1:
dload 0
dreturn
ldc2_w 0.0
dreturn
.end method
.method public static main([Ljava/lang/String;)V
.limit stack 50
.limit locals 50
ldc2_w 1000.0
dstore 0
ldc2_w 0.05
dstore 2
ldc2_w 10.0
dstore 4
dload 0
dstore 6
getstatic java/lang/System/out Ljava/io/PrintStream;
dload 6
invokevirtual java/io/PrintStream/println(D)V
dload 2
dstore 8
getstatic java/lang/System/out Ljava/io/PrintStream;
dload 8
invokevirtual java/io/PrintStream/println(D)V
dload 4
dstore 10
getstatic java/lang/System/out Ljava/io/PrintStream;
dload 10
invokevirtual java/io/PrintStream/println(D)V
dload 0
dload 2
dload 4
invokestatic Main/interesCompuesto(DDD)D
dstore 12
dload 12
dstore 14
getstatic java/lang/System/out Ljava/io/PrintStream;
dload 14
invokevirtual java/io/PrintStream/println(D)V
dload 12
dload 0
dsub
dstore 16
dload 16
dstore 18
getstatic java/lang/System/out Ljava/io/PrintStream;
dload 18
invokevirtual java/io/PrintStream/println(D)V
dload 16
ldc2_w 500.0
dcmpl
ifgt condTrue_6
ldc 0
goto condEnd_7
condTrue_6:
ldc 1
condEnd_7:
ifeq else_4
ldc2_w 1.0
dstore 20
getstatic java/lang/System/out Ljava/io/PrintStream;
dload 20
invokevirtual java/io/PrintStream/println(D)V
goto endif_5
else_4:
ldc2_w 0.0
dstore 22
getstatic java/lang/System/out Ljava/io/PrintStream;
dload 22
invokevirtual java/io/PrintStream/println(D)V
endif_5:
return
.end method
