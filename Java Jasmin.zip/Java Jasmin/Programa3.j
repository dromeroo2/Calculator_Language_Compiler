.class public Main
.super java/lang/Object

.method public static maximoComunDivisor(DD)D
.limit stack 50
.limit locals 50
whileStart_0:
dload 2
ldc2_w 0.0
dcmpl
ifgt condTrue_2
ldc 0
goto condEnd_3
condTrue_2:
ldc 1
condEnd_3:
ifeq whileEnd_1
dload 2
dstore 4
dload 0
dload 2
drem
dstore 2
dload 4
dstore 0
goto whileStart_0
whileEnd_1:
dload 0
dreturn
ldc2_w 0.0
dreturn
.end method
.method public static main([Ljava/lang/String;)V
.limit stack 50
.limit locals 50
ldc2_w 48.0
dstore 0
ldc2_w 18.0
dstore 2
dload 0
dstore 4
getstatic java/lang/System/out Ljava/io/PrintStream;
dload 4
invokevirtual java/io/PrintStream/println(D)V
dload 2
dstore 6
getstatic java/lang/System/out Ljava/io/PrintStream;
dload 6
invokevirtual java/io/PrintStream/println(D)V
dload 0
dload 2
invokestatic Main/maximoComunDivisor(DD)D
dstore 8
dload 8
dstore 10
getstatic java/lang/System/out Ljava/io/PrintStream;
dload 10
invokevirtual java/io/PrintStream/println(D)V
ldc2_w 1.0
dstore 12
dload 8
dstore 14
forStart_4:
dload 12
dload 14
dcmpl
ifgt forEnd_5
dload 0
dload 12
drem
dstore 16
dload 2
dload 12
drem
dstore 18
dload 16
ldc2_w 0.0
dcmpl
ifeq condTrue_8
ldc 0
goto condEnd_9
condTrue_8:
ldc 1
condEnd_9:
ifeq else_6
dload 18
ldc2_w 0.0
dcmpl
ifeq condTrue_12
ldc 0
goto condEnd_13
condTrue_12:
ldc 1
condEnd_13:
ifeq else_10
dload 12
dstore 20
getstatic java/lang/System/out Ljava/io/PrintStream;
dload 20
invokevirtual java/io/PrintStream/println(D)V
goto endif_11
else_10:
endif_11:
goto endif_7
else_6:
endif_7:
dload 12
ldc2_w 1.0
dadd
dstore 12
goto forStart_4
forEnd_5:
return
.end method
